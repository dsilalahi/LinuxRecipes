package stubs;

public class OutputAvroTopic {

}
