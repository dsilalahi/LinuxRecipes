package stubs;

public class ManualOffsetManagement {
}
