package stubs;

public class CustomPartitioner {

}
