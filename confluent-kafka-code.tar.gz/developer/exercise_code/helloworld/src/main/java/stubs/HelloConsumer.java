package stubs;



public class HelloConsumer {

}
