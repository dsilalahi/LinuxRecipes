#!/usr/bin/python

import requests
import base64
import json
import sys
import os


offsets_filename = "offsets.txt"

