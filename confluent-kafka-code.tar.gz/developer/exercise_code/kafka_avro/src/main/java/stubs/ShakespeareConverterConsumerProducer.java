package stubs;

public class ShakespeareConverterConsumerProducer {

}
