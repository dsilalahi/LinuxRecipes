package stubs;

public class ShakespeareProducer {

}
