package stubs;

public class ShakespeareAvroConsumer {

}
