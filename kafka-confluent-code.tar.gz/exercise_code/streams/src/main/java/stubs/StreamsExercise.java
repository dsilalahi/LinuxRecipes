package stubs;

public class StreamsExercise {

}
