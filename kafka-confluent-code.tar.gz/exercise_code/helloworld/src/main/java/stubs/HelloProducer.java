package stubs;


public class HelloProducer {
}