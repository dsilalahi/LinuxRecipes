package stubs;

public class PreviousFullConsumer {

}
